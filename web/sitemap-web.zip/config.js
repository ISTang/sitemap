exports.HTTPD_PORT = 8082;

exports.GRACE_EXIT_TIME = 1500; // ms

exports.REDIS_SERVER = "192.168.35.165"; // 111.9.140.253
exports.REDIS_PORT = 6379;

exports.LOG_ENABLED = true;
